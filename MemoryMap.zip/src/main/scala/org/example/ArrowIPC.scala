import org.apache.arrow.memory.{BufferAllocator, RootAllocator}
import org.apache.arrow.vector.{FieldVector, IntVector, VectorSchemaRoot}
import org.apache.arrow.vector.ipc.{ArrowFileWriter, ArrowStreamReader, ArrowStreamWriter}
import org.apache.arrow.vector.types.pojo.{ArrowType, Field, FieldType, Schema}

import java.io.FileInputStream
import java.net.{ServerSocket, Socket}
import java.nio.channels.Channels
import scala.collection.JavaConverters._

object ArrowIPC {
  def main(args: Array[String]): Unit = {
    val allocator: BufferAllocator = new RootAllocator()

    val field: Field = new Field("int_field", FieldType.nullable(new ArrowType.Int(32, true)), null)
    val schema: Schema = new Schema(List(field).asJava)

    val serverSocket = new ServerSocket(9090)
    println("Server is listening on port 9090")
    val filePath = ""

    var fileInputStream = new FileInputStream(filePath)
    var reader = new ArrowStreamReader(fileInputStream, allocator)
    var root = reader.getVectorSchemaRoot
    while (true) {
      val socket: Socket = serverSocket.accept()
      println("New client connected")

      val writer = new ArrowFileWriter(root, null, Channels.newChannel(socket.getOutputStream))

      try {
        writer.start()
        writer.writeBatch()
        while (reader.loadNextBatch) {
          System.out.println("Read batch with " + root.getRowCount + " rows.")
          root = reader.getVectorSchemaRoot
          writer.writeBatch()
        }
        writer.end()
      } finally {
        writer.close()
        root.close()
        socket.close()
      }
    }
  }
}

